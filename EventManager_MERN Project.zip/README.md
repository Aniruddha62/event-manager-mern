
# Simple MERN Event Manager

## Backend
cd backend
npm install
Create .env file using .env.example
npm run dev

## Frontend
cd frontend
npm install
npm start
